public class Main {
    public static void main(String[] args) {

        Usuario usuario = new Usuario();
        Solicitacao solicitacao = new Solicitacao();

        usuario.nome = "Ana Clara";
        usuario.cfp = "100.000.000-00";
        usuario.telefone = "3188000162";
        solicitacao.nomeSolicitante = "Maria Jose";
        solicitacao.cpfSolicitante = "000.001.000-80";
        solicitacao.problemaRelatado = "Falta de energia no bairro Celvia";
        solicitacao.solucaoProblema = "Enviar um tecnico na propriedade do usuario";

        usuario.cadastrarUsuario();
        usuario.fazerLogin();
        solicitacao.cadatrarSolitacao();
        solicitacao.alterarSolicitacao();
        solicitacao.buscarSolitacao();

    }
}