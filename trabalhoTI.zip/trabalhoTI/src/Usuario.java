public class Usuario {

   private int id;
    String nome;
    String cfp;
    String telefone;
   private String senha;

   void cadastrarUsuario() {
    System.out.println("Id: " + id);
    System.out.println("Nome do usuario: " + nome);
    System.out.println("CPF: " + cfp);
    System.out.println("Telefone: " + telefone);
   }
   void fazerLogin(){

   }
}
