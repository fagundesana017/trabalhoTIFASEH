public class Solicitacao {

     private int idSolicitacao;
     String nomeSolicitante;
     String telefoneSolicitante;
     String cpfSolicitante;
     String problemaRelatado;
     String solucaoProblema;
     int idAtedente;
     int idAnalisaSolucionador;
     String statusSolicitacao;

     void cadatrarSolitacao(){

     }
     void buscarSolitacao(){

     }
     void alterarSolicitacao(){

     }

}
